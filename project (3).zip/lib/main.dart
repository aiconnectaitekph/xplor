import 'package:flutter/material.dart';
    import 'package:explorejobs_app/models/post.dart';
    import 'package:explorejobs_app/screens/home_screen.dart';
    import 'package:explorejobs_app/screens/candidates_screen.dart';
    import 'package:explorejobs_app/screens/companies_screen.dart';
    import 'package:explorejobs_app/screens/job_offers_screen.dart';
    import 'package:explorejobs_app/screens/dashboard_screen.dart';
    import 'package:explorejobs_app/screens/messenger_screen.dart';
    import 'package:explorejobs_app/services/wordpress_api.dart';
    import 'package:provider/provider.dart';

    void main() {
      runApp(
        ChangeNotifierProvider(
          create: (context) => WordPressAPI(),
          child: const MyApp(),
        ),
      );
    }

    class MyApp extends StatelessWidget {
      const MyApp({Key? key}) : super(key: key);

      @override
      Widget build(BuildContext context) {
        return MaterialApp(
          title: 'ExploreJobs App',
          theme: ThemeData(
            primarySwatch: Colors.blue,
          ),
          home: const HomeScreen(),
        );
      }
    }
