import 'package:flutter/material.dart';
    import 'package:http/http.dart' as http;
    import 'package:explorejobs_app/models/post.dart';
    import 'dart:convert';

    class WordPressAPI extends ChangeNotifier {
      final String _baseUrl = 'https://explorejobs.com.my/wp-json/'; // Replace with your WordPress API URL
      List<Post> _posts = [];

      List<Post> get posts => _posts;

      Future<void> fetchPosts({String? category}) async {
        final url = category != null
            ? '$_baseUrl/wp/v2/posts?categories=$category'
            : '$_baseUrl/wp/v2/posts';
        final response = await http.get(Uri.parse(url));

        if (response.statusCode == 200) {
          final data = jsonDecode(response.body) as List;
          _posts = data.map((post) => Post.fromJson(post)).toList();
          notifyListeners();
        } else {
          // Handle error
        }
      }
    }
