import 'package:flutter/material.dart';
    import 'package:explorejobs_app/models/post.dart';
    import 'package:explorejobs_app/services/wordpress_api.dart';
    import 'package:provider/provider.dart';

    class CandidatesScreen extends StatefulWidget {
      const CandidatesScreen({Key? key}) : super(key: key);

      @override
      State<CandidatesScreen> createState() => _CandidatesScreenState();
    }

    class _CandidatesScreenState extends State<CandidatesScreen> {
      @override
      void initState() {
        super.initState();
        context.read<WordPressAPI>().fetchPosts(category: 'candidates');
      }

      @override
      Widget build(BuildContext context) {
        final posts = context.watch<WordPressAPI>().posts;

        return Scaffold(
          appBar: AppBar(
            title: const Text('Candidates'),
          ),
          body: ListView.builder(
            itemCount: posts.length,
            itemBuilder: (context, index) {
              final post = posts[index];
              return ListTile(
                title: Text(post.title),
                subtitle: Text(post.excerpt),
              );
            },
          ),
          bottomNavigationBar: BottomNavigationBar(
            items: const [
              BottomNavigationBarItem(
                icon: Icon(Icons.home),
                label: 'Home',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.people),
                label: 'Candidates',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.business),
                label: 'Companies',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.work),
                label: 'Job Offers',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.dashboard),
                label: 'Dashboard',
              ),
            ],
            currentIndex: 1,
            onTap: (index) {
              switch (index) {
                case 0:
                  Navigator.pushReplacementNamed(context, '/');
                  break;
                case 1:
                  Navigator.pushReplacementNamed(context, '/candidates');
                  break;
                case 2:
                  Navigator.pushReplacementNamed(context, '/companies');
                  break;
                case 3:
                  Navigator.pushReplacementNamed(context, '/job-offers');
                  break;
                case 4:
                  Navigator.pushReplacementNamed(context, '/dashboard');
                  break;
              }
            },
          ),
        );
      }
    }
